<footer class="purple">
        <div class="text-center p-3" style="color:antiquewhite;">
           © 2021 Copyright Team Blackout
        </div>
      </footer>
</body>

